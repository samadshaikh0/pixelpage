import 'dart:io';
import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'view_images.dart';

class QRScannerPage extends StatefulWidget {
  const QRScannerPage({super.key});

  @override
  State<QRScannerPage> createState() => _QRScannerPageState();
}

class _QRScannerPageState extends State<QRScannerPage> {
  final MobileScannerController _cameraController = MobileScannerController();
  bool _isScanning = true;
  final String _qrPrefix = "BsFyKhSwTa";
  String? _directoryStatus;
  String? _createdDirectoryPath;

  List<File> _images = [];

  @override
  void dispose() {
    _cameraController.dispose();
    super.dispose();
  }

  Future<bool> _requestStoragePermission() async {
    final androidInfo = await DeviceInfoPlugin().androidInfo;
    final sdkInt = androidInfo.version.sdkInt;

    if (sdkInt >= 33) {
      final status = await [Permission.photos, Permission.videos].request();
      return status[Permission.photos]!.isGranted || status[Permission.videos]!.isGranted;
    } else if (sdkInt >= 30) {
      return await Permission.manageExternalStorage.request().isGranted;
    } else {
      return await Permission.storage.request().isGranted;
    }
  }

  Future<Directory?> _getBaseDirectory() async {
    final baseDir = await getExternalStorageDirectory();
    if (baseDir == null) {
      _setStatus('Could not access storage directory');
      return null;
    }
    return baseDir;
  }

  Future<void> _createFolderStructure(String bookId, String qrId) async {
    if (!await _requestStoragePermission()) {
      _setStatus('Storage permission denied');
      return;
    }

    final baseDir = await _getBaseDirectory();
    if (baseDir == null) return;

    try {
      final bookFolder = Directory('${baseDir.path}/$bookId');
      if (!await bookFolder.exists()) {
        await bookFolder.create(recursive: true);
      }

      final qrFolder = Directory('${bookFolder.path}/$qrId');
      if (!await qrFolder.exists()) {
        await qrFolder.create(recursive: true);
      }

      _createdDirectoryPath = qrFolder.path;
      _setStatus('Scanned Successfully!');
    } catch (e) {
      _setStatus('Error creating folders: $e');
    }
  }

  Future<List<File>> _loadImages(String bookId, String qrId) async {
    final baseDir = await _getBaseDirectory();
    if (baseDir == null) return [];

    try {
      final dir = Directory('${baseDir.path}/$bookId/$qrId');
      if (!await dir.exists()) {
        _setStatus('Images directory does not exist');
        return [];
      }

      return dir
          .listSync()
          .whereType<File>()
          .where((file) => const ['.jpg', '.jpeg', '.png']
          .any((ext) => file.path.toLowerCase().endsWith(ext)))
          .toList();
    } catch (e) {
      _setStatus('Error loading images: $e');
      return [];
    }
  }

  void _handleDetection(BarcodeCapture barcodeCapture) async {
    if (!_isScanning) return;

    final scannedText = barcodeCapture.barcodes.first.rawValue ?? '';

    if (!scannedText.startsWith(_qrPrefix)) {
      _showInvalidQrDialog('This QR does not match the expected prefix. Please scan a valid one.');
      return;
    }

    final parts = scannedText.split('_');

    if (parts.length != 3 || parts[0] != _qrPrefix || parts[1].isEmpty || parts[2].isEmpty) {
      _isScanning = false;
      _showInvalidQrDialog('Invalid QR code format! Please scan a QR From book');
      return;
    }

    final bookId = parts[1];
    final qrId = parts[2];

    _isScanning = false;
    await _cameraController.stop();

    await _createFolderStructure(bookId, qrId);
    final loadedImages = await _loadImages(bookId, qrId);

    if (mounted) {
      Navigator.pushReplacement(
        context,
        PageRouteBuilder(
          transitionDuration: const Duration(milliseconds: 250),
          pageBuilder: (_, __, ___) =>
              ViewImages(images: loadedImages, qrId: qrId, bookId: bookId),
          transitionsBuilder: (_, animation, __, child) =>
              FadeTransition(opacity: animation, child: child),
        ),
      );
    }
  }


  void _showInvalidQrDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Invalid QR Code'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context); // Close the dialog
              _isScanning = true;     // Allow scanning again
            },
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }


  void _setStatus(String status) {
    if (mounted) {
      setState(() => _directoryStatus = status);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('QR Scanner'),
        actions: [
          if (_images.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.close),
              onPressed: () => setState(() {
                _images.clear();
                _directoryStatus = null;
              }),
            ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Expanded(
              flex: 4,
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 10,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: MobileScanner(
                    controller: _cameraController,
                    onDetect: _handleDetection,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              flex: 2,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                    'Scan a QR code',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                  ),
                  const SizedBox(height: 8),

                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
