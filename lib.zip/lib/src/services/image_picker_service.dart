import 'dart:io';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';



class ImagePickerService {
  final ImagePicker _picker = ImagePicker();

  // Check and request permissions for gallery access or saving
  Future<bool> checkAndRequestPermissions(
      {required BuildContext context, bool forSaving = false}) async {
    if (!Platform.isAndroid) return true;

    final androidInfo = await DeviceInfoPlugin().androidInfo;
    final sdkInt = androidInfo.version.sdkInt;

    List<Permission> permissions = [];
    if (forSaving && sdkInt < 33) {
      permissions.add(Permission.storage);
    } else if (!forSaving) {
      permissions.add(sdkInt >= 33 ? Permission.photos : Permission.storage);
    }

    bool allGranted = true;
    for (var permission in permissions) {
      var status = await permission.status;
      if (!status.isGranted) {
        status = await permission.request();

        if (!status.isGranted) {
          if (status.isPermanentlyDenied) {
            await _showSettingsDialog(context);
          } else {
            await _showPermissionRationaleDialog(context, permission);
          }
          allGranted = false;
        }
      }
    }

    return allGranted;
  }

  // Show permission rationale dialog
  Future<void> _showPermissionRationaleDialog(
      BuildContext context, Permission permission) async {
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Permission Required'),
        content: Text(
          'This app needs ${permission == Permission.photos ? "photo" : "storage"} access to ${permission == Permission.photos ? "pick images from your gallery" : "save images"}. Please grant the permission.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  // Show settings dialog
  Future<void> _showSettingsDialog(BuildContext context) async {
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Permission Denied'),
        content: const Text(
          'Storage or photo access is required. Please enable it in the app settings.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              await openAppSettings();
            },
            child: const Text('Open Settings'),
          ),
        ],
      ),
    );
  }

  // Pick images from camera or gallery
  Future<List<File>?> pickImages(
      {required BuildContext context, required ImageSource source}) async {
    try {
      if (source == ImageSource.gallery &&
          !await checkAndRequestPermissions(context: context)) {
        return null;
      }

      if (source == ImageSource.gallery) {
        final List<XFile>? pickedFiles = await _picker.pickMultiImage();
        if (pickedFiles != null && pickedFiles.isNotEmpty) {
          return pickedFiles.map((xfile) => File(xfile.path)).toList();
        }
      } else {
        final XFile? pickedFile = await _picker.pickImage(source: source);
        if (pickedFile != null) {
          return [File(pickedFile.path)];
        }
      }
      return null;
    } catch (e) {
      debugPrint('Error picking image: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error picking image: $e')),
      );
      return null;
    }
  }

  // Save images to app-specific storage
  Future<List<File>?> saveImages({
    required BuildContext context,
    required List<File> images,
    required String bookId,
    required String qrId,
  }) async {
    if (images.isEmpty || qrId.isEmpty || bookId.isEmpty) {
      debugPrint('SaveImages: Invalid input (empty images, bookId, or qrId)');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No images to save or invalid book/qr ID')),
      );
      return null;
    }

    try {
      if (!await checkAndRequestPermissions(context: context, forSaving: true)) {
        debugPrint('SaveImages: Permission denied for saving');
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Storage permission denied')),
        );
        return null;
      }

      final baseDir = await getExternalStorageDirectory();
      if (baseDir == null) {
        debugPrint('Error: Could not get external storage directory');
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Cannot access storage directory')),
        );
        return null;
      }

      final dir = Directory('${baseDir.path}/$bookId/$qrId');



      debugPrint('SaveImages: Saving to directory: $dir');

      if (!await dir.exists()) {
        await dir.create(recursive: true);
        debugPrint('SaveImages: Created directory: $dir');
      }

      final List<File> savedFiles = [];
      for (final image in images) {
        final fileName = 'image_${DateTime.now().millisecondsSinceEpoch}_${images.indexOf(image)}.jpg';
        final newImagePath = '${dir.path}/$fileName';
        final newFile = File(newImagePath);

        final bytes = await image.readAsBytes();
        await File(newImagePath).writeAsBytes(bytes);

        savedFiles.add(newFile);
      }


      // Return all images in the directory
      final allImages = dir
          .listSync()
          .whereType<File>()
          .where((file) => file.path.toLowerCase().endsWith('.jpg') ||
          file.path.toLowerCase().endsWith('.jpeg') ||
          file.path.toLowerCase().endsWith('.png'))
          .toList();

      debugPrint('SaveImages: Found ${allImages.length} images in directory');

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Images saved successfully')),
      );

      return allImages;
    } catch (e) {
      debugPrint('SaveImages: Error saving images: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error saving images: $e')),
      );
      return null;
    }
  }
}