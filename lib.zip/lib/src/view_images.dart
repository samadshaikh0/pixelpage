import 'package:flutter/material.dart';
import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'services/image_picker_service.dart';
// import 'image_upload.dart';

class ViewImages extends StatefulWidget {
  final List<File> images;
  final String qrId;
  final String bookId;
  const ViewImages({
    super.key,
    required this.images,
    required this.qrId,
    required this.bookId,
  });

  @override
  State<ViewImages> createState() => _ViewImagesState();
}

class _ViewImagesState extends State<ViewImages> {
  bool deleteMode = false;
  bool shareMode = false;
  final Set<File> selectedImages = {};
  final ImagePickerService _pickerService = ImagePickerService();

  // Show bottom sheet for image source selection
  void _showImageSourceBottomSheet() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) => Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt),
              title: const Text('Camera'),
              onTap: () async {
                Navigator.pop(context);
                await _pickAndSaveImages(ImageSource.camera);
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: const Text('Gallery'),
              onTap: () async {
                Navigator.pop(context);
                await _pickAndSaveImages(ImageSource.gallery);
              },
            ),
            ListTile(
              leading: const Icon(Icons.cancel),
              title: const Text('Cancel'),
              onTap: () => Navigator.pop(context),
            ),
          ],
        ),
      ),
    );
  }

  // Pick and save images
  Future<void> _pickAndSaveImages(ImageSource source) async {
    try {
      final images = await _pickerService.pickImages(
        context: context,
        source: source,
      );
      if (images != null && images.isNotEmpty) {
        debugPrint('Picked ${images.length} images');
        final savedImages = await _pickerService.saveImages(
          context: context,
          images: images,
          bookId: widget.bookId,
          qrId: widget.qrId,
        );
        if (savedImages != null && mounted) {
          setState(() {
            widget.images.clear();
            widget.images.addAll(savedImages);
            debugPrint('Updated UI with ${widget.images.length} images');
          });
        } else {
          debugPrint('No images saved');
        }
      } else {
        debugPrint('No images picked');
      }
    } catch (e) {
      debugPrint('Error in pickAndSaveImages: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error processing images: $e')),
        );
      }
    }
  }

  void _shareSelectedImages() async {
    if (selectedImages.isEmpty) return;

    try {
      final externalDir = await getApplicationDocumentsDirectory();
      List<String> sharePaths = [];

      for (var file in selectedImages) {
        final newPath = '${externalDir.path}/${file.path.split('/').last}';
        final sharedCopy = await file.copy(newPath);
        sharePaths.add(sharedCopy.path);
      }

      await Share.shareFiles(sharePaths);
      setState(() {
        selectedImages.clear();
        shareMode = false;
      });
    } catch (e) {
      debugPrint('Sharing error: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error sharing images: $e')),
      );
    }
  }

  void _confirmAndDeleteSelected() async {
    if (selectedImages.isEmpty) return;

    bool? confirm = await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Delete Images'),
        content: const Text('Are you sure you want to delete selected images?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      try {
        final List<File> newImages = List.from(widget.images);
        for (final file in selectedImages) {
          if (await file.exists()) {
            await file.delete();
            newImages.remove(file);
          }
        }
        setState(() {
          widget.images.clear();
          widget.images.addAll(newImages);
          selectedImages.clear();
          deleteMode = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Images deleted successfully'),
            duration: Duration(seconds: 2),
          ),
        );
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error deleting images: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Images"),
        actions: [
          IconButton(
            icon: Icon(shareMode ? Icons.close : Icons.share),
            onPressed: () {
              setState(() {
                shareMode = !shareMode;
                deleteMode = false;
                selectedImages.clear();
              });
            },
          ),
          IconButton(
            icon: Icon(deleteMode ? Icons.close : Icons.delete),
            onPressed: () {
              setState(() {
                deleteMode = !deleteMode;
                shareMode = false;
                selectedImages.clear();
              });
            },
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showImageSourceBottomSheet,
        child: const Icon(Icons.add_a_photo),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.startFloat,
      body: Stack(
        children: [
          widget.images.isEmpty
              ? const Center(
            child: Text(
              'No images found for this QR',
              style: TextStyle(fontSize: 16, color: Colors.grey),
            ),
          )
              : GridView.builder(
            padding: const EdgeInsets.all(8),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              crossAxisSpacing: 8,
              mainAxisSpacing: 8,
            ),
            itemCount: widget.images.length,
            itemBuilder: (context, index) {
              final image = widget.images[index];
              final isSelected = selectedImages.contains(image);

              return GestureDetector(
                onTap: () {
                  if (shareMode || deleteMode) {
                    setState(() {
                      if (isSelected) {
                        selectedImages.remove(image);
                      } else {
                        selectedImages.add(image);
                      }
                    });
                  } else {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ImageViewerPage(
                          images: widget.images,
                          initialIndex: index,
                        ),
                      ),
                    );
                  }
                },
                child: Stack(
                  children: [
                    Positioned.fill(
                      child: Image.file(
                        image,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) =>
                        const Icon(Icons.error, color: Colors.red),
                        cacheHeight: 200,
                      ),
                    ),
                    if (isSelected)
                      Positioned(
                        top: 8,
                        right: 8,
                        child: CircleAvatar(
                          backgroundColor: Colors.blue,
                          child: const Icon(Icons.check, color: Colors.white),
                        ),
                      ),
                  ],
                ),
              );
            },
          ),
          if ((deleteMode || shareMode) && selectedImages.isNotEmpty)
            Positioned(
              bottom: 16,
              right: 16,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (deleteMode)
                    FloatingActionButton(
                      heroTag: "delete",
                      onPressed: _confirmAndDeleteSelected,
                      backgroundColor: Colors.red,
                      child: const Icon(Icons.delete_forever),
                    ),
                  if (deleteMode && shareMode) const SizedBox(height: 8),
                  if (shareMode)
                    FloatingActionButton(
                      heroTag: "share",
                      onPressed: _shareSelectedImages,
                      backgroundColor: Colors.blue,
                      child: const Icon(Icons.send),
                    ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

class ZoomableImage extends StatefulWidget {
  final File file;

  const ZoomableImage({super.key, required this.file});

  @override
  State<ZoomableImage> createState() => _ZoomableImageState();
}

class _ZoomableImageState extends State<ZoomableImage> {
  final TransformationController _controller = TransformationController();
  TapDownDetails? _doubleTapDetails;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onDoubleTapDown: (details) {
        _doubleTapDetails = details;
      },
      onDoubleTap: () {
        final position = _doubleTapDetails?.localPosition;
        if (_controller.value != Matrix4.identity()) {
          _controller.value = Matrix4.identity();
        } else if (position != null) {
          _controller.value = Matrix4.identity()
            ..translate(-position.dx * 2, -position.dy * 2)
            ..scale(3.0);
        }
      },
      child: InteractiveViewer(
        transformationController: _controller,
        minScale: 1.0,
        maxScale: 5.0,
        panEnabled: true,
        scaleEnabled: true,
        child: Image.file(
          widget.file,
          fit: BoxFit.contain,
          width: double.infinity,
          height: double.infinity,
          cacheWidth: 1000,
          errorBuilder: (context, error, stackTrace) =>
          const Icon(Icons.error, color: Colors.red, size: 50),
        ),
      ),
    );
  }
}



// ImageViewerPage remains unchanged
class ImageViewerPage extends StatefulWidget {
  final List<File> images;
  final int initialIndex;

  const ImageViewerPage({
    super.key,
    required this.images,
    required this.initialIndex,
  });


  @override
  State<ImageViewerPage> createState() => _ImageViewerPageState();
}

class _ImageViewerPageState extends State<ImageViewerPage> {
  late PageController _pageController;
  late int _currentIndex;

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.initialIndex;
    _pageController = PageController(initialPage: _currentIndex);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text("${_currentIndex + 1} / ${widget.images.length}"),
        leading: IconButton(
          icon: const Icon(Icons.close, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      backgroundColor: Colors.black,
      body: PageView.builder(
        controller: _pageController,
        itemCount: widget.images.length,
        onPageChanged: (index) {
          setState(() => _currentIndex = index);
        },
        itemBuilder: (context, index) {
          return Center(
            child: ZoomableImage(file: widget.images[index]),
          );

        },
      ),
    );
  }
}